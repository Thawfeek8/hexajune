package com.hexaware.fastx.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.List;

@Entity
@Table(name = "buses")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Bus {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long busId;
    
    @ManyToOne
    @JoinColumn(name = "operator_id", nullable = false)
    private BusOperator operator;
    
    @Column(nullable = false)
    private String busNumber;
    
    @Column(nullable = false)
    private String busName;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private BusType busType;
    
    @Column(nullable = false)
    private Integer totalSeats;
    
    private String amenities;
    
    @OneToMany(mappedBy = "bus", cascade = CascadeType.ALL)
    private List<Route> routes;
}