package com.hexaware.fastx.service;

import com.hexaware.fastx.model.BusOperator;
import com.hexaware.fastx.repo.BusOperatorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BusOperatorService {
    @Autowired
    private BusOperatorRepository operatorRepo;

    public BusOperator createOperator(BusOperator operator) {
        return operatorRepo.save(operator);
    }

    public BusOperator getOperatorById(Long operatorId) {
        return operatorRepo.findById(operatorId).orElse(null);
    }

    public List<BusOperator> getAllOperators() {
        return operatorRepo.findAll();
    }

    public BusOperator updateOperator(BusOperator operator) {
        if (operatorRepo.existsById(operator.getOperatorId())) {
            return operatorRepo.save(operator);
        }
        return null;
    }

    public void deleteOperator(Long operatorId) {
        operatorRepo.deleteById(operatorId);
    }

    public BusOperator findByUsername(String username) {
        return operatorRepo.findByUsername(username).orElse(null);
    }
}