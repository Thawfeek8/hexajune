package com.hexaware.fastx.service;

import com.hexaware.fastx.model.BusOperator;
import com.hexaware.fastx.model.User;
import com.hexaware.fastx.repo.BusOperatorRepository;
import com.hexaware.fastx.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private BusOperatorRepository busOperatorRepository;
    
    public User authenticateUser(String username, String password) {
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new RuntimeException("User not found"));
        
        if (!password.equals(user.getPassword())) {
            throw new RuntimeException("Invalid password");
        }
        
        return user;
    }
    
    public BusOperator authenticateOperator(String username, String password) {
        BusOperator operator = busOperatorRepository.findByUsername(username)
            .orElseThrow(() -> new RuntimeException("Operator not found"));
        
        if (!password.equals(operator.getPassword())) {
            throw new RuntimeException("Invalid password");
        }
        
        return operator;
    }
}