package com.hexaware.fastx.model;

public enum BusType {
    SLEEPER_AC, SLEEPER_NON_AC, SEATER_AC, SEATER_NON_AC
}