package com.hexaware.fastx.service;

import com.hexaware.fastx.model.Route;
import com.hexaware.fastx.repo.RouteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class RouteService {
    @Autowired
    private RouteRepository routeRepo;

    public Route addRoute(Route route) {
        return routeRepo.save(route);
    }

    public Route getRouteById(Long routeId) {
        return routeRepo.findById(routeId).orElse(null);
    }

    public List<Route> getAllRoutes() {
        return routeRepo.findAll();
    }

    public List<Route> getRoutesByBus(Long busId) {
        return routeRepo.findByBus_BusId(busId);
    }

    public Route updateRoute(Route route) {
        if (routeRepo.existsById(route.getRouteId())) {
            return routeRepo.save(route);
        }
        return null;
    }

    public void deleteRoute(Long routeId) {
        routeRepo.deleteById(routeId);
    }
}