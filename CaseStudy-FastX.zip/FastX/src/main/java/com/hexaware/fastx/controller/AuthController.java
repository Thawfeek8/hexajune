package com.hexaware.fastx.controller;

import com.hexaware.fastx.model.BusOperator;
import com.hexaware.fastx.model.User;
import com.hexaware.fastx.service.AuthService;
import com.hexaware.fastx.service.BusOperatorService;
import com.hexaware.fastx.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @Autowired
    private AuthService authService;
    @Autowired
    private UserService userService;
    @Autowired
    private BusOperatorService busOperatorService;
    
    @PostMapping("/register/user")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        User registeredUser = userService.registerUser(user);
        return ResponseEntity.ok(registeredUser);
    }
    
    @PostMapping("/register/operator")
    public ResponseEntity<BusOperator> registerOperator(@RequestBody BusOperator operator) {
        BusOperator registeredOperator = busOperatorService.registerOperator(operator);
        return ResponseEntity.ok(registeredOperator);
    }
    
    @PostMapping("/login/user")
    public ResponseEntity<User> loginUser(@RequestParam String username, @RequestParam String password) {
        User user = authService.authenticateUser(username, password);
        return ResponseEntity.ok(user);
    }
    
    @PostMapping("/login/operator")
    public ResponseEntity<BusOperator> loginOperator(@RequestParam String username, @RequestParam String password) {
        BusOperator operator = authService.authenticateOperator(username, password);
        return ResponseEntity.ok(operator);
    }
}