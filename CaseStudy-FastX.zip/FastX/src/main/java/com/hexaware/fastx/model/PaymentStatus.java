package com.hexaware.fastx.model;

public enum PaymentStatus {
    PAID, PENDING, REFUNDED
}