package com.hexaware.fastx.repo;

import com.hexaware.fastx.model.Route;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RouteRepository extends JpaRepository<Route, Long> {
    List<Route> findByOriginAndDestinationAndAvailableDaysContaining(
        String origin, String destination, String day);
    
    List<Route> findByBus_Operator_OperatorId(Long operatorId);
}