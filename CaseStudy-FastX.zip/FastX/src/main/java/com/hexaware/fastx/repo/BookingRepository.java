package com.hexaware.fastx.repo;

import com.hexaware.fastx.model.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BookingRepository extends JpaRepository<Booking, Long> {
    List<Booking> findByUser_UserId(Long userId);
    List<Booking> findByRoute_Bus_Operator_OperatorId(Long operatorId);
}