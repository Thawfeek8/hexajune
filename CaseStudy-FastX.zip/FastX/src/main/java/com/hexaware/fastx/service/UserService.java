package com.hexaware.fastx.service;

import com.hexaware.fastx.model.User;
import com.hexaware.fastx.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepo;

    public User createUser(User user) {
        return userRepo.save(user);
    }

    public User getUserById(Long userId) {
        return userRepo.findById(userId).orElse(null);
    }

    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    public User updateUser(User user) {
        if (userRepo.existsById(user.getUserId())) {
            return userRepo.save(user);
        }
        return null;
    }

    public void deleteUser(Long userId) {
        userRepo.deleteById(userId);
    }

    public User findByUsername(String username) {
        return userRepo.findByUsername(username).orElse(null);
    }
}