package com.hexaware.fastx.repo;

import com.hexaware.fastx.model.BusOperator;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface BusOperatorRepository extends JpaRepository<BusOperator, Long> {
    Optional<BusOperator> findByUsername(String username);
    Optional<BusOperator> findByEmail(String email);
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}