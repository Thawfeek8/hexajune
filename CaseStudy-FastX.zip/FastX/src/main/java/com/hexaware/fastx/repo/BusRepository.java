package com.hexaware.fastx.repo;

import com.hexaware.fastx.model.Bus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface BusRepository extends JpaRepository<Bus, Long> {
    List<Bus> findByOperator_OperatorId(Long operatorId);
}