package com.hexaware.fastx.service;

import com.hexaware.fastx.model.Bus;
import com.hexaware.fastx.repo.BusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BusService {
    @Autowired
    private BusRepository busRepo;

    public Bus addBus(Bus bus) {
        return busRepo.save(bus);
    }

    public Bus getBusById(Long busId) {
        return busRepo.findById(busId).orElse(null);
    }

    public List<Bus> getAllBuses() {
        return busRepo.findAll();
    }

    public List<Bus> getBusesByOperator(Long operatorId) {
        return busRepo.findByOperator_OperatorId(operatorId);
    }

    public Bus updateBus(Bus bus) {
        if (busRepo.existsById(bus.getBusId())) {
            return busRepo.save(bus);
        }
        return null;
    }

    public void deleteBus(Long busId) {
        busRepo.deleteById(busId);
    }
}