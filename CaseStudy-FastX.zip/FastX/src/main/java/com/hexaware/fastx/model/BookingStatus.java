package com.hexaware.fastx.model;

public enum BookingStatus {
    CONFIRMED, CANCELLED, COMPLETED
}