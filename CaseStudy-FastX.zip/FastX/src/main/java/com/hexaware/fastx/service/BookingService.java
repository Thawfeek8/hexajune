package com.hexaware.fastx.service;

import com.hexaware.fastx.model.Booking;
import com.hexaware.fastx.repo.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepo;

    public Booking createBooking(Booking booking) {
        return bookingRepo.save(booking);
    }

    public Booking getBookingById(Long bookingId) {
        return bookingRepo.findById(bookingId).orElse(null);
    }

    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }

    public List<Booking> getBookingsByUser(Long userId) {
        return bookingRepo.findByUser_UserId(userId);
    }

    public Booking updateBooking(Booking booking) {
        if (bookingRepo.existsById(booking.getBookingId())) {
            return bookingRepo.save(booking);
        }
        return null;
    }

    public void deleteBooking(Long bookingId) {
        bookingRepo.deleteById(bookingId);
    }
}